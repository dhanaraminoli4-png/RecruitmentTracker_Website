using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecruitmentTracker.Data;
using RecruitmentTracker.Models;

namespace RecruitmentTracker.Controllers
{
    [Authorize(Roles = "HiringManager")]
    public class HiringManagerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;


        public HiringManagerController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }


        // =========================================================
        // APPLICATIONS SENT TO HIRING MANAGER
        // =========================================================

        public async Task<IActionResult> Applications()
        {
            var applications =
                await _context.JobApplications

                    .Include(a =>
                        a.Candidate)

                    .Include(a =>
                        a.JobVacancy)

                    .Where(a =>
                        a.HRShortlisted)

                    .OrderBy(a =>
                        a.HiringManagerReviewed)

                    .ThenByDescending(a =>
                        a.AIScore)

                    .ToListAsync();


            return View(
                applications
            );
        }


        // =========================================================
        // VIEW APPLICATION BEFORE INTERVIEW APPROVAL
        // =========================================================

        public async Task<IActionResult> Review(
            int id)
        {
            var application =
                await _context.JobApplications

                    .Include(a =>
                        a.Candidate)

                    .Include(a =>
                        a.JobVacancy)

                    .FirstOrDefaultAsync(a =>
                        a.Id == id &&
                        a.HRShortlisted);


            if (application == null)
            {
                return NotFound();
            }


            return View(
                application
            );
        }


        // =========================================================
        // APPROVE CANDIDATE FOR INTERVIEW
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveForInterview(
            int id,
            string? comments)
        {
            var application =
                await _context.JobApplications

                    .FirstOrDefaultAsync(a =>
                        a.Id == id &&
                        a.HRShortlisted);


            if (application == null)
            {
                return NotFound();
            }


            application.HiringManagerReviewed =
                true;


            application.HiringManagerShortlisted =
                true;


            application.HiringManagerDecision =
                "ApprovedForInterview";


            application.HiringManagerComments =
                comments ?? "";


            application.Status =
                "Shortlisted";


            if (string.IsNullOrWhiteSpace(
                application.InterviewStageStatus))
            {
                application.InterviewStageStatus =
                    "Not Started";
            }


            await _context.SaveChangesAsync();


            TempData["Success"] =
                "Candidate approved for interview.";


            return RedirectToAction(
                nameof(Review),
                new
                {
                    id
                }
            );
        }


        // =========================================================
        // REJECT BEFORE INTERVIEW
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(
            int id,
            string? comments)
        {
            var application =
                await _context.JobApplications

                    .FirstOrDefaultAsync(a =>
                        a.Id == id &&
                        a.HRShortlisted);


            if (application == null)
            {
                return NotFound();
            }


            application.HiringManagerReviewed =
                true;


            application.HiringManagerShortlisted =
                false;


            application.HiringManagerDecision =
                "Rejected";


            application.HiringManagerComments =
                comments ?? "";


            application.Status =
                "Shortlisted";


            await _context.SaveChangesAsync();


            TempData["Success"] =
                "Hiring Manager decision recorded as rejected.";


            return RedirectToAction(
                nameof(Review),
                new
                {
                    id
                }
            );
        }


        // =========================================================
        // INTERVIEWS WAITING FOR HM ROUND DECISION
        //
        // /HiringManager/InterviewReviews
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> InterviewReviews()
        {
            var interviews =
                await _context.Interviews

                    .Include(x =>
                        x.JobApplication)

                        .ThenInclude(x =>
                            x.Candidate)

                    .Include(x =>
                        x.JobApplication)

                        .ThenInclude(x =>
                            x.JobVacancy)

                    .Include(x =>
                        x.InterviewRound)

                    .Include(x =>
                        x.InterviewType)

                    .Include(x =>
                        x.Assessments)

                        .ThenInclude(x =>
                            x.AssessmentTemplate)

                    .Include(x =>
                        x.Feedbacks)

                        .ThenInclude(x =>
                            x.Interviewer)

                    .Where(x =>

                        x.JobApplication != null

                        &&

                        x.JobApplication
                            .HiringManagerDecision ==
                                "ApprovedForInterview"
                    )

                    .OrderBy(x =>
                        x.RoundResult ==
                            "Pending"
                            ? 0
                            : 1)

                    .ThenByDescending(x =>
                        x.InterviewDate)

                    .ThenByDescending(x =>
                        x.InterviewTime)

                    .AsSplitQuery()

                    .ToListAsync();


            return View(
                interviews
            );
        }


        // =========================================================
        // REVIEW ONE INTERVIEW ROUND
        //
        // /HiringManager/InterviewReview/5
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> InterviewReview(
            int id)
        {
            var interview =
                await _context.Interviews

                    .Include(x =>
                        x.JobApplication)

                        .ThenInclude(x =>
                            x.Candidate)

                    .Include(x =>
                        x.JobApplication)

                        .ThenInclude(x =>
                            x.JobVacancy)

                    .Include(x =>
                        x.InterviewRound)

                    .Include(x =>
                        x.InterviewType)

                    .Include(x =>
                        x.Assessments)

                        .ThenInclude(x =>
                            x.AssessmentTemplate)

                            .ThenInclude(x =>
                                x.Questions)

                    .Include(x =>
                        x.Assessments)

                        .ThenInclude(x =>
                            x.Answers)

                    .Include(x =>
                        x.Feedbacks)

                        .ThenInclude(x =>
                            x.Interviewer)

                    .AsSplitQuery()

                    .FirstOrDefaultAsync(x =>
                        x.Id == id);


            if (interview == null)
            {
                return NotFound();
            }


            if (interview.JobApplication == null ||
                interview.JobApplication
                    .HiringManagerDecision !=
                        "ApprovedForInterview")
            {
                return Forbid();
            }


            // =====================================================
            // PREVIOUS INTERVIEW ROUNDS
            // =====================================================

            var currentSequence =
                interview.InterviewRound
                    ?.SequenceNumber
                ?? 0;


            var previousInterviews =
                await _context.Interviews

                    .Include(x =>
                        x.InterviewRound)

                    .Include(x =>
                        x.InterviewType)

                    .Include(x =>
                        x.Assessments)

                    .Include(x =>
                        x.Feedbacks)

                    .Where(x =>
                        x.JobApplicationId ==
                            interview.JobApplicationId

                        &&

                        x.Id !=
                            interview.Id

                        &&

                        x.InterviewRound != null

                        &&

                        x.InterviewRound.SequenceNumber <
                            currentSequence)

                    .OrderBy(x =>
                        x.InterviewRound!
                            .SequenceNumber)

                    .AsSplitQuery()

                    .ToListAsync();


            ViewBag.PreviousInterviews =
                previousInterviews;


            return View(
                interview
            );
        }


        // =========================================================
        // HM ROUND DECISION
        //
        // PASS / FAIL
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DecideRound(
            int interviewId,
            string decision,
            string? notes)
        {
            var manager =
                await _userManager
                    .GetUserAsync(User);


            if (manager == null)
            {
                return Challenge();
            }


            var interview =
                await _context.Interviews

                    .Include(x =>
                        x.JobApplication)

                            .ThenInclude(x =>
                                x.JobVacancy)

                    .Include(x =>
                        x.InterviewRound)

                    .Include(x =>
                        x.Assessments)

                    .Include(x =>
                        x.Feedbacks)

                    .FirstOrDefaultAsync(x =>
                        x.Id ==
                            interviewId);


            if (interview == null ||
                interview.JobApplication == null ||
                interview.InterviewRound == null)
            {
                return NotFound();
            }


            var application =
                interview.JobApplication;


            // =====================================================
            // SECURITY / WORKFLOW CHECK
            // =====================================================

            if (application.HiringManagerDecision !=
                "ApprovedForInterview")
            {
                return Forbid();
            }


            // HM should review only after interviewer work is done.
            if (interview.Status != "Completed")
            {
                TempData["Error"] =
                    "The interviewer has not completed this interview yet.";


                return RedirectToAction(
                    nameof(InterviewReview),
                    new
                    {
                        id =
                            interviewId
                    }
                );
            }


            if (decision != "Pass" &&
                decision != "Fail")
            {
                TempData["Error"] =
                    "Please choose Pass or Fail.";


                return RedirectToAction(
                    nameof(InterviewReview),
                    new
                    {
                        id =
                            interviewId
                    }
                );
            }


            // =====================================================
            // RECORD DECISION
            // =====================================================

            interview.RoundDecisionBy =
                manager.FullName
                ?? manager.Email
                ?? "Hiring Manager";


            interview.RoundDecisionDate =
                DateTime.Now;


            interview.RoundDecisionNotes =
                string.IsNullOrWhiteSpace(
                    notes)

                    ? null

                    : notes.Trim();


            // =====================================================
            // FAIL ROUND
            // =====================================================

            if (decision == "Fail")
            {
                interview.RoundResult =
                    "Failed";


                application.InterviewStageStatus =
                    "Failed";


                application.InterviewProcessCompleted =
                    true;


                application.InterviewDecisionBy =
                    manager.FullName
                    ?? manager.Email
                    ?? "Hiring Manager";


                application.InterviewDecisionDate =
                    DateTime.Now;


                await _context.SaveChangesAsync();


                TempData["Success"] =
                    "Candidate failed this interview round.";


                return RedirectToAction(
                    nameof(InterviewReview),
                    new
                    {
                        id =
                            interviewId
                    }
                );
            }


            // =====================================================
            // PASS ROUND
            // =====================================================

            interview.RoundResult =
                "Passed";


            // =====================================================
            // FIND ALL ACTIVE ROUNDS FOR THIS VACANCY
            // =====================================================

            var activeRounds =
                await _context.InterviewRounds

                    .Where(x =>
                        x.JobVacancyId ==
                            application.JobVacancyId

                        &&

                        x.IsActive)

                    .OrderBy(x =>
                        x.SequenceNumber)

                    .ToListAsync();


            var currentSequence =
                interview.InterviewRound
                    .SequenceNumber;


            var nextRound =
                activeRounds

                    .FirstOrDefault(x =>
                        x.SequenceNumber >
                            currentSequence);


            // =====================================================
            // FINAL ROUND PASSED
            // =====================================================

            if (nextRound == null)
            {
                application.InterviewStageStatus =
                    "Completed";


                application.InterviewProcessCompleted =
                    true;


                application.InterviewDecisionBy =
                    manager.FullName
                    ?? manager.Email
                    ?? "Hiring Manager";


                application.InterviewDecisionDate =
                    DateTime.Now;


                TempData["Success"] =
                    "Candidate passed the final interview round. Interview process completed.";
            }

            // =====================================================
            // MORE ROUNDS REMAIN
            // =====================================================

            else
            {
                application.InterviewStageStatus =
                    "In Progress";


                application.InterviewProcessCompleted =
                    false;


                TempData["Success"] =
                    $"Round passed. Candidate can now proceed to Round {nextRound.SequenceNumber} � {nextRound.Name}.";
            }


            await _context.SaveChangesAsync();


            return RedirectToAction(
                nameof(InterviewReview),
                new
                {
                    id =
                        interviewId
                }
            );
        }
    }
}