﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecruitmentTracker.Data;
using RecruitmentTracker.Models;

namespace RecruitmentTracker.Controllers
{
    [Authorize(Roles = "Interviewer")]
    public class InterviewerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public InterviewerController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }


        // =========================================================
        // MY CALENDAR
        // =========================================================

        public async Task<IActionResult> Calendar()
        {
            var interviewer =
                await _userManager.GetUserAsync(User);

            if (interviewer == null)
            {
                return Challenge();
            }


            // Make sure interviewer completed profile first
            if (!interviewer.InterviewerProfileCompleted)
            {
                return RedirectToAction(
                    "Setup",
                    "InterviewerProfile");
            }


            ViewBag.InterviewerName =
                interviewer.FullName
                ?? interviewer.Email
                ?? "Interviewer";

            ViewBag.JobTitle =
                interviewer.JobTitle ?? "";

            ViewBag.Department =
                interviewer.Department ?? "";

            return View();
        }



        // =========================================================
        // GET MY CALENDAR EVENTS
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> GetEvents(
            DateTime start,
            DateTime end)
        {
            var interviewer =
                await _userManager.GetUserAsync(User);


            if (interviewer == null)
            {
                return Unauthorized();
            }


            var events =
                await _context.InterviewerSchedules

                    .Where(x =>
                        x.InterviewerId == interviewer.Id &&

                        // Do not show deleted records
                        !x.IsDeleted &&

                        x.StartDateTime < end &&
                        x.EndDateTime > start)

                    .OrderBy(x =>
                        x.StartDateTime)

                    .Select(x => new
                    {
                        id = x.Id,

                        title =
                            x.Title
                            ?? x.ScheduleType,

                        start =
                            x.StartDateTime,

                        end =
                            x.EndDateTime,

                        allDay =
                            x.IsAllDay,

                        scheduleType =
                            x.ScheduleType,

                        notes =
                            x.Notes,

                        isSystemGenerated =
                            x.IsSystemGenerated,


                        // =========================================
                        // AUDIT INFORMATION
                        // =========================================

                        createdBy =
                            x.CreatedBy,

                        createdAt =
                            x.CreatedAt,

                        updatedBy =
                            x.UpdatedBy,

                        updatedAt =
                            x.UpdatedAt
                    })

                    .ToListAsync();


            return Json(events);
        }



        // =========================================================
        // ADD CALENDAR EVENT
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddEvent(
            DateTime start,
            DateTime end,
            string scheduleType,
            string? title,
            string? notes,
            bool isAllDay = false)
        {
            var interviewer =
                await _userManager.GetUserAsync(User);


            if (interviewer == null)
            {
                return Unauthorized();
            }


            if (end <= start)
            {
                return BadRequest(
                    "End time must be after the start time.");
            }


            var allowedTypes =
                new[]
                {
                    "Meeting",
                    "Training",
                    "Leave",
                    "Personal",
                    "CompanyEvent",
                    "Other"
                };


            if (!allowedTypes.Contains(scheduleType))
            {
                return BadRequest(
                    "Invalid schedule type.");
            }


            var schedule =
                new InterviewerSchedule
                {
                    InterviewerId =
                        interviewer.Id,

                    StartDateTime =
                        start,

                    EndDateTime =
                        end,

                    IsAllDay =
                        isAllDay,

                    ScheduleType =
                        scheduleType,

                    Title =
                        string.IsNullOrWhiteSpace(title)
                            ? scheduleType
                            : title.Trim(),

                    Notes =
                        string.IsNullOrWhiteSpace(notes)
                            ? null
                            : notes.Trim(),

                    IsSystemGenerated =
                        false,


                    // =========================================
                    // CREATED AUDIT
                    // =========================================

                    CreatedBy =
                        interviewer.FullName
                        ?? interviewer.Email
                        ?? "Interviewer",

                    CreatedAt =
                        DateTime.Now,


                    // =========================================
                    // DELETE STATE
                    // =========================================

                    IsDeleted =
                        false
                };


            _context.InterviewerSchedules
                .Add(schedule);


            await _context.SaveChangesAsync();


            return Json(new
            {
                success = true,

                message =
                    "Schedule created successfully."
            });
        }



        // =========================================================
        // UPDATE CALENDAR EVENT
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateEvent(
            int id,
            DateTime start,
            DateTime end,
            string scheduleType,
            string? title,
            string? notes,
            bool isAllDay = false)
        {
            var interviewer =
                await _userManager.GetUserAsync(User);


            if (interviewer == null)
            {
                return Unauthorized();
            }


            var schedule =
                await _context.InterviewerSchedules

                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&

                        x.InterviewerId ==
                            interviewer.Id &&

                        !x.IsDeleted);


            if (schedule == null)
            {
                return NotFound();
            }


            // Interviews created by HireTrack
            // cannot be edited manually.
            if (schedule.IsSystemGenerated)
            {
                return BadRequest(
                    "Scheduled interviews cannot be edited.");
            }


            if (end <= start)
            {
                return BadRequest(
                    "End time must be after the start time.");
            }


            var allowedTypes =
                new[]
                {
                    "Meeting",
                    "Training",
                    "Leave",
                    "Personal",
                    "CompanyEvent",
                    "Other"
                };


            if (!allowedTypes.Contains(scheduleType))
            {
                return BadRequest(
                    "Invalid schedule type.");
            }


            // =============================================
            // UPDATE SCHEDULE
            // =============================================

            schedule.StartDateTime =
                start;

            schedule.EndDateTime =
                end;

            schedule.IsAllDay =
                isAllDay;

            schedule.ScheduleType =
                scheduleType;

            schedule.Title =
                string.IsNullOrWhiteSpace(title)
                    ? scheduleType
                    : title.Trim();

            schedule.Notes =
                string.IsNullOrWhiteSpace(notes)
                    ? null
                    : notes.Trim();


            // =============================================
            // UPDATE AUDIT
            // =============================================

            schedule.UpdatedBy =
                interviewer.FullName
                ?? interviewer.Email
                ?? "Interviewer";

            schedule.UpdatedAt =
                DateTime.Now;


            await _context.SaveChangesAsync();


            return Json(new
            {
                success = true,

                message =
                    "Schedule updated successfully."
            });
        }



        // =========================================================
        // DELETE CALENDAR EVENT
        // SOFT DELETE
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteEvent(
            int id)
        {
            var interviewer =
                await _userManager.GetUserAsync(User);


            if (interviewer == null)
            {
                return Unauthorized();
            }


            var schedule =
                await _context.InterviewerSchedules

                    .FirstOrDefaultAsync(x =>
                        x.Id == id &&

                        x.InterviewerId ==
                            interviewer.Id &&

                        !x.IsDeleted);


            if (schedule == null)
            {
                return NotFound();
            }


            if (schedule.IsSystemGenerated)
            {
                return BadRequest(
                    "Scheduled interviews cannot be deleted.");
            }


            // =============================================
            // SOFT DELETE
            // Do NOT remove the database record.
            // =============================================

            schedule.IsDeleted =
                true;


            schedule.DeletedBy =
                interviewer.FullName
                ?? interviewer.Email
                ?? "Interviewer";


            schedule.DeletedAt =
                DateTime.Now;


            await _context.SaveChangesAsync();


            return Json(new
            {
                success = true,

                message =
                    "Schedule deleted successfully."
            });
        }
    }
}