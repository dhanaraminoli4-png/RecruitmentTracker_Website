﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RecruitmentTracker.Data;
using RecruitmentTracker.Models;
using System.Text.RegularExpressions;

namespace RecruitmentTracker.Controllers
{
    [Authorize(Roles = "HR")]
    public class InterviewController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public InterviewController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }


        // =========================================================
        // MAIN INTERVIEW PAGE
        // /Interview
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var interviews =
                await _context.Interviews

                    .Include(x => x.JobApplication)
                        .ThenInclude(x => x.Candidate)

                    .Include(x => x.JobApplication)
                        .ThenInclude(x => x.JobVacancy)

                    .Include(x => x.InterviewRound)

                    .Include(x => x.InterviewType)

                    .OrderByDescending(x =>
                        x.InterviewDate)

                    .ThenByDescending(x =>
                        x.InterviewTime)

                    .ToListAsync();


            return View(interviews);
        }


        // =========================================================
        // OPEN SCHEDULE INTERVIEW MODAL
        // /Interview/Schedule
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> Schedule()
        {
            // -----------------------------------------------------
            // ACTIVE JOBS
            // -----------------------------------------------------

            var jobs =
                await _context.JobVacancies

                    .Where(x =>
                        x.IsActive)

                    .OrderBy(x =>
                        x.JobTitle)

                    .ToListAsync();


            // -----------------------------------------------------
            // INTERVIEW TYPES
            // -----------------------------------------------------

            var interviewTypes =
                await _context.InterviewTypes

                    .OrderBy(x =>
                        x.Name)

                    .ToListAsync();


            // -----------------------------------------------------
            // We DO NOT show interviewers here directly anymore.
            //
            // They will be loaded later using
            // GetAvailableInterviewers()
            // after date/time/job/duration are selected.
            // -----------------------------------------------------

            var model =
                new ScheduleInterviewViewModel
                {
                    Jobs =
                        jobs
                            .Select(x =>
                                new SelectListItem
                                {
                                    Value =
                                        x.Id.ToString(),

                                    Text =
                                        x.JobTitle
                                })
                            .ToList(),


                    InterviewTypes =
                        interviewTypes
                            .Select(x =>
                                new SelectListItem
                                {
                                    Value =
                                        x.Id.ToString(),

                                    Text =
                                        x.Name
                                })
                            .ToList(),


                    // Keep empty because cards are loaded dynamically.
                    Interviewers =
                        new List<SelectListItem>(),


                    InterviewDate =
                        DateTime.Today,


                    DurationMinutes =
                        60
                };


            return PartialView(
                "_ScheduleInterview",
                model
            );
        }

        // =========================================================
        // SAVE / SCHEDULE INTERVIEWS
        // =========================================================

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Schedule(
            ScheduleInterviewViewModel model)
        {
            // Candidate required
            if (model.SelectedApplicationIds == null ||
                model.SelectedApplicationIds.Count == 0)
            {
                ModelState.AddModelError(
                    nameof(model.SelectedApplicationIds),
                    "Please select at least one candidate."
                );
            }

            // Interviewer required
            if (model.SelectedInterviewerIds == null ||
                model.SelectedInterviewerIds.Count == 0)
            {
                ModelState.AddModelError(
                    nameof(model.SelectedInterviewerIds),
                    "Please select at least one interviewer."
                );
            }

            if (model.DurationMinutes <= 0)
            {
                ModelState.AddModelError(
                    nameof(model.DurationMinutes),
                    "Please enter a valid duration."
                );
            }


            // =====================================================
            // RECHECK SELECTED INTERVIEWERS
            // Never trust only the browser availability result
            // =====================================================

            if (ModelState.IsValid)
            {
                var vacancy =
                    await _context.JobVacancies
                        .FirstOrDefaultAsync(x =>
                            x.Id == model.JobVacancyId);

                if (vacancy == null)
                {
                    ModelState.AddModelError(
                        "",
                        "Selected job could not be found."
                    );
                }
                else
                {
                    var interviewStart =
                        model.InterviewDate.Date
                            .Add(model.InterviewTime);

                    var interviewEnd =
                        interviewStart.AddMinutes(
                            model.DurationMinutes);


                    foreach (var interviewerId
                        in model.SelectedInterviewerIds!)
                    {
                        var interviewer =
                            await _userManager
                                .FindByIdAsync(interviewerId);


                        if (interviewer == null ||
                            !IsEligibleInterviewer(
                                interviewer,
                                vacancy))
                        {
                            ModelState.AddModelError(
                                "",
                                "One of the selected interviewers is no longer eligible."
                            );

                            break;
                        }


                        var conflict =
                            await _context.InterviewerSchedules
                                .AnyAsync(x =>

                                    x.InterviewerId ==
                                        interviewerId

                                    &&

                                    !x.IsDeleted

                                    &&

                                    x.StartDateTime <
                                        interviewEnd

                                    &&

                                    x.EndDateTime >
                                        interviewStart
                                );


                        if (conflict)
                        {
                            ModelState.AddModelError(
                                "",
                                $"{interviewer.FullName ?? interviewer.Email} is no longer available at that time."
                            );

                            break;
                        }
                    }
                }
            }


            // =====================================================
            // VALIDATION FAILED
            // =====================================================

            if (!ModelState.IsValid)
            {
                TempData["Error"] =
                    string.Join(
                        " ",
                        ModelState.Values
                            .SelectMany(x => x.Errors)
                            .Select(x => x.ErrorMessage)
                    );

                return RedirectToAction(
                    nameof(Index)
                );
            }


            // =====================================================
            // ONLY HM-APPROVED APPLICATIONS
            // =====================================================

            var validApplicationIds =
                await _context.JobApplications

                    .Where(a =>

                        model.SelectedApplicationIds!
                            .Contains(a.Id)

                        &&

                        a.JobVacancyId ==
                            model.JobVacancyId

                        &&

                        a.HRShortlisted == true

                        &&

                        a.HiringManagerDecision ==
                            "ApprovedForInterview"
                    )

                    .Select(a => a.Id)

                    .ToListAsync();


            if (validApplicationIds.Count == 0)
            {
                TempData["Error"] =
                    "No valid candidates were selected.";

                return RedirectToAction(
                    nameof(Index)
                );
            }


            // =====================================================
            // CREATE INTERVIEWS
            // =====================================================

            foreach (var applicationId
                in validApplicationIds)
            {
                var interview =
                    new Interview
                    {
                        JobApplicationId =
                            applicationId,

                        InterviewRoundId =
                            model.InterviewRoundId,

                        InterviewTypeId =
                            model.InterviewTypeId,

                        InterviewDate =
                            model.InterviewDate.Date,

                        InterviewTime =
                            model.InterviewTime,

                        DurationMinutes =
                            model.DurationMinutes,

                        Location =
                            model.Location,

                        MeetingLink =
                            model.MeetingLink,

                        InterviewerIds =
                            string.Join(
                                ",",
                                model.SelectedInterviewerIds!
                            ),

                        Status =
                            "Scheduled",

                        FeedbackStatus =
                            "Pending",

                        CreatedDate =
                            DateTime.Now
                    };


                _context.Interviews.Add(
                    interview
                );


                // Save first so Interview.Id is generated
                await _context.SaveChangesAsync();


                // =================================================
                // ADD LOCKED INTERVIEW TO EACH INTERVIEWER CALENDAR
                // =================================================

                var interviewStart =
                    model.InterviewDate.Date
                        .Add(model.InterviewTime);

                var interviewEnd =
                    interviewStart.AddMinutes(
                        model.DurationMinutes);


                foreach (var interviewerId
                    in model.SelectedInterviewerIds!)
                {
                    var calendarEvent =
                        new InterviewerSchedule
                        {
                            InterviewerId =
                                interviewerId,

                            StartDateTime =
                                interviewStart,

                            EndDateTime =
                                interviewEnd,

                            IsAllDay =
                                false,

                            ScheduleType =
                                "Interview",

                            Title =
                                "Candidate Interview",

                            Notes =
                                $"Interview for application #{applicationId}",

                            IsSystemGenerated =
                                true,

                            InterviewId =
                                interview.Id,

                            IsDeleted =
                                false,

                            CreatedBy =
                                "HireTrack",

                            CreatedAt =
                                DateTime.Now
                        };


                    _context.InterviewerSchedules
                        .Add(calendarEvent);
                }


                await _context.SaveChangesAsync();
            }


            TempData["Success"] =
                $"{validApplicationIds.Count} interview(s) scheduled successfully.";


            return RedirectToAction(
                nameof(Index)
            );
        }

        // =========================================================
        // GET CANDIDATES
        //
        // Only candidates:
        // HR shortlisted
        // AND
        // Hiring Manager approved for interview
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> GetCandidates(
            int jobId)
        {
            var candidates =
                await _context.JobApplications

                    .Include(x =>
                        x.Candidate)

                    .Where(x =>

                        x.JobVacancyId ==
                            jobId

                        &&

                        x.HRShortlisted ==
                            true

                        &&

                        x.HiringManagerDecision ==
                            "ApprovedForInterview"
                    )

                    .OrderByDescending(x =>
                        x.AIScore)

                    .Select(x =>
                        new
                        {
                            applicationId =
                                x.Id,

                            name =
                                x.Candidate != null
                                    ? x.Candidate.FullName
                                    : "Unknown Candidate",

                            email =
                                x.Candidate != null
                                    ? x.Candidate.Email
                                    : "",

                            aiScore =
                                x.AIScore
                        })

                    .ToListAsync();


            return Json(candidates);
        }


        // =========================================================
        // GET INTERVIEW ROUNDS FOR SELECTED JOB
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> GetRounds(
            int jobId)
        {
            var rounds =
                await _context.InterviewRounds

                    .Where(x =>

                        x.JobVacancyId ==
                            jobId

                        &&

                        x.IsActive
                    )

                    .OrderBy(x =>
                        x.SequenceNumber)

                    .Select(x =>
                        new
                        {
                            id =
                                x.Id,

                            name =
                                x.Name,

                            sequence =
                                x.SequenceNumber
                        })

                    .ToListAsync();


            return Json(rounds);
        }


        // =========================================================
        // GET ELIGIBLE + AVAILABLE INTERVIEWERS
        // =========================================================

        [HttpGet]
        public async Task<IActionResult> GetAvailableInterviewers(
            int jobId,
            DateTime date,
            TimeSpan time,
            int durationMinutes)
        {
            if (jobId <= 0)
            {
                return BadRequest(
                    "Invalid job."
                );
            }


            if (durationMinutes <= 0)
            {
                return BadRequest(
                    "Invalid interview duration."
                );
            }


            // =====================================================
            // FIND VACANCY
            // =====================================================

            var vacancy =
                await _context.JobVacancies
                    .FirstOrDefaultAsync(
                        x => x.Id == jobId
                    );


            if (vacancy == null)
            {
                return NotFound(
                    "Job vacancy not found."
                );
            }


            // =====================================================
            // BUILD INTERVIEW TIME RANGE
            // =====================================================

            var interviewStart =
                date.Date.Add(time);


            var interviewEnd =
                interviewStart.AddMinutes(
                    durationMinutes
                );


            // =====================================================
            // GET ALL INTERVIEWERS
            // =====================================================

            var interviewers =
                await _userManager
                    .GetUsersInRoleAsync(
                        "Interviewer"
                    );


            var availableInterviewers =
                new List<object>();


            // =====================================================
            // CHECK EACH INTERVIEWER
            // =====================================================

            foreach (var interviewer in interviewers)
            {
                // =================================================
                // 1. ELIGIBILITY
                // =================================================

                if (!IsEligibleInterviewer(
                    interviewer,
                    vacancy))
                {
                    continue;
                }


                // =================================================
                // 2. CALENDAR AVAILABILITY
                // =================================================

                var hasConflict =
                    await _context
                        .InterviewerSchedules

                        .AnyAsync(schedule =>

                            schedule.InterviewerId ==
                                interviewer.Id

                            &&

                            !schedule.IsDeleted

                            &&

                            schedule.StartDateTime <
                                interviewEnd

                            &&

                            schedule.EndDateTime >
                                interviewStart
                        );


                if (hasConflict)
                {
                    continue;
                }


                // =================================================
                // ELIGIBLE + AVAILABLE
                // =================================================

                availableInterviewers.Add(
                    new
                    {
                        id =
                            interviewer.Id,

                        name =
                            interviewer.FullName
                            ?? interviewer.Email
                            ?? "Interviewer",

                        email =
                            interviewer.Email
                            ?? "",

                        jobTitle =
                            interviewer.JobTitle
                            ?? "",

                        department =
                            interviewer.Department
                            ?? "",

                        seniority =
                            interviewer.SeniorityLevel
                            ?? "",

                        yearsOfExperience =
                            interviewer.YearsOfExperience,

                        skills =
                            interviewer.Skills
                            ?? ""
                    }
                );
            }


            return Json(
                availableInterviewers
            );
        }


        // =========================================================
        // INTERVIEWER ELIGIBILITY
        // =========================================================

        private bool IsEligibleInterviewer(
            ApplicationUser interviewer,
            JobVacancy vacancy)
        {
            // =====================================================
            // 1. PROFILE MUST BE COMPLETED
            // =====================================================

            if (!interviewer.InterviewerProfileCompleted)
            {
                return false;
            }


            // =====================================================
            // 2. DEPARTMENT MUST MATCH
            // =====================================================

            if (!DepartmentMatches(
                interviewer.Department,
                vacancy.Department))
            {
                return false;
            }


            // =====================================================
            // 3. DETERMINE VACANCY SENIORITY
            // =====================================================

            var vacancySeniority =
                GetVacancySeniority(
                    vacancy.JobTitle
                );


            // =====================================================
            // 4. INTERVIEWER SENIORITY
            // =====================================================

            var interviewerSeniority =
                GetInterviewerSeniorityRank(
                    interviewer.SeniorityLevel
                );


            // Interviewer must be same level
            // or above the vacancy level.
            if (interviewerSeniority <
                vacancySeniority)
            {
                return false;
            }


            // =====================================================
            // 5. EXPERIENCE CHECK
            // =====================================================

            var minimumExperience =
                GetMinimumInterviewerExperience(
                    vacancySeniority
                );


            if (interviewer.YearsOfExperience <
                minimumExperience)
            {
                return false;
            }


            // =====================================================
            // 6. JOB AREA RELEVANCE
            //
            // Avoid rejecting valid interviewers because of small
            // wording differences.
            //
            // We accept them when either:
            // - their title matches the vacancy field
            // OR
            // - their skills match the vacancy
            // =====================================================

            var titleMatches =
                JobAreaMatches(
                    interviewer.JobTitle,
                    vacancy.JobTitle
                );


            var skillsMatch =
                SkillsMatchVacancy(
                    interviewer.Skills,
                    vacancy
                );


            if (!titleMatches &&
                !skillsMatch)
            {
                return false;
            }


            return true;
        }


        // =========================================================
        // DEPARTMENT MATCH
        // =========================================================

        private bool DepartmentMatches(
            string? interviewerDepartment,
            string? vacancyDepartment)
        {
            // Vacancy has no department:
            // do not reject interviewer.
            if (string.IsNullOrWhiteSpace(
                vacancyDepartment))
            {
                return true;
            }


            if (string.IsNullOrWhiteSpace(
                interviewerDepartment))
            {
                return false;
            }


            var interviewerValue =
                NormalizeDepartment(
                    interviewerDepartment
                );


            var vacancyValue =
                NormalizeDepartment(
                    vacancyDepartment
                );


            return
                interviewerValue ==
                    vacancyValue

                ||

                interviewerValue.Contains(
                    vacancyValue
                )

                ||

                vacancyValue.Contains(
                    interviewerValue
                );
        }


        // =========================================================
        // NORMALIZE DEPARTMENT NAMES
        // =========================================================

        private string NormalizeDepartment(
            string value)
        {
            var text =
                value
                    .Trim()
                    .ToLowerInvariant()
                    .Replace("&", "and");


            // AI
            if (
                text == "ai" ||
                text.Contains(
                    "artificial intelligence"
                )
            )
            {
                return "artificial intelligence";
            }


            // Machine Learning
            if (
                text == "ml" ||
                text.Contains(
                    "machine learning"
                )
            )
            {
                return "machine learning";
            }


            // IT
            if (
                text == "it" ||
                text.Contains(
                    "information technology"
                )
            )
            {
                return "information technology";
            }


            // HR
            if (
                text == "hr" ||
                text.Contains(
                    "human resources"
                )
            )
            {
                return "human resources";
            }


            // Data Science
            if (
                text == "ds" ||
                text.Contains(
                    "data science"
                )
            )
            {
                return "data science";
            }


            return text;
        }


        // =========================================================
        // VACANCY SENIORITY
        //
        // Rank:
        // 1 = Intern / Trainee
        // 2 = Junior
        // 3 = Mid / Normal
        // 4 = Senior
        // 5 = Lead / Principal / Manager
        // =========================================================

        private int GetVacancySeniority(
            string? jobTitle)
        {
            if (string.IsNullOrWhiteSpace(
                jobTitle))
            {
                return 3;
            }


            var title =
                jobTitle
                    .Trim()
                    .ToLowerInvariant();


            if (
                ContainsWord(
                    title,
                    "lead"
                )

                ||

                ContainsWord(
                    title,
                    "principal"
                )

                ||

                ContainsWord(
                    title,
                    "manager"
                )
            )
            {
                return 5;
            }


            if (
                ContainsWord(
                    title,
                    "senior"
                )

                ||

                ContainsWord(
                    title,
                    "sr"
                )
            )
            {
                return 4;
            }


            if (
                ContainsWord(
                    title,
                    "mid"
                )

                ||

                title.Contains(
                    "mid-level"
                )

                ||

                ContainsWord(
                    title,
                    "intermediate"
                )
            )
            {
                return 3;
            }


            if (
                ContainsWord(
                    title,
                    "junior"
                )

                ||

                ContainsWord(
                    title,
                    "jr"
                )
            )
            {
                return 2;
            }


            if (
                ContainsWord(
                    title,
                    "intern"
                )

                ||

                ContainsWord(
                    title,
                    "trainee"
                )
            )
            {
                return 1;
            }


            // Example:
            // AI Engineer
            //
            // If no level is stated,
            // treat it as mid-level for interviewer selection.
            return 3;
        }


        // =========================================================
        // INTERVIEWER SENIORITY
        // =========================================================

        private int GetInterviewerSeniorityRank(
            string? seniority)
        {
            if (string.IsNullOrWhiteSpace(
                seniority))
            {
                return 0;
            }


            var value =
                seniority
                    .Trim()
                    .ToLowerInvariant();


            return value switch
            {
                "intern" => 1,
                "trainee" => 1,

                "junior" => 2,
                "jr" => 2,
                "junior level" => 2,
                "junior-level" => 2,

                "mid" => 3,
                "mid level" => 3,
                "mid-level" => 3,
                "intermediate" => 3,

                "senior" => 4,
                "sr" => 4,
                "senior level" => 4,
                "senior-level" => 4,

                "lead" => 5,
                "principal" => 5,
                "manager" => 5,

                _ => 0
            };
        }


        // =========================================================
        // MINIMUM INTERVIEWER EXPERIENCE
        // =========================================================

        private int GetMinimumInterviewerExperience(
            int vacancySeniority)
        {
            return vacancySeniority switch
            {
                // Intern / Trainee vacancy
                1 => 1,

                // Junior vacancy
                2 => 2,

                // Normal / Mid vacancy
                3 => 3,

                // Senior vacancy
                4 => 5,

                // Lead / Principal / Manager vacancy
                5 => 7,

                _ => 3
            };
        }


        // =========================================================
        // JOB AREA MATCH
        // =========================================================

        private bool JobAreaMatches(
            string? interviewerJobTitle,
            string? vacancyJobTitle)
        {
            if (string.IsNullOrWhiteSpace(
                vacancyJobTitle))
            {
                return true;
            }


            if (string.IsNullOrWhiteSpace(
                interviewerJobTitle))
            {
                return false;
            }


            var interviewerKeywords =
                GetJobKeywords(
                    interviewerJobTitle
                );


            var vacancyKeywords =
                GetJobKeywords(
                    vacancyJobTitle
                );


            if (interviewerKeywords.Count == 0 ||
                vacancyKeywords.Count == 0)
            {
                return false;
            }


            return interviewerKeywords
                .Intersect(
                    vacancyKeywords,
                    StringComparer.OrdinalIgnoreCase
                )
                .Any();
        }


        // =========================================================
        // JOB KEYWORDS
        // =========================================================

        private List<string> GetJobKeywords(
            string text)
        {
            var ignoredWords =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase)
                {
                    "senior",
                    "junior",
                    "mid",
                    "lead",
                    "principal",
                    "manager",
                    "intern",
                    "trainee",

                    "engineer",
                    "developer",
                    "specialist",
                    "officer",
                    "executive",
                    "associate",

                    "sr",
                    "jr",

                    "and",
                    "or",
                    "the",
                    "for",
                    "of",
                    "with"
                };


            var words =
                text
                    .ToLowerInvariant()

                    .Split(
                        new[]
                        {
                            ' ',
                            '-',
                            '/',
                            ',',
                            '(',
                            ')',
                            '.'
                        },
                        StringSplitOptions.RemoveEmptyEntries
                    )

                    .Select(
                        x => x.Trim()
                    )

                    .Where(
                        x =>
                            x.Length >= 2 &&
                            !ignoredWords.Contains(x)
                    )

                    .Select(
                        NormalizeJobKeyword
                    )

                    .Distinct(
                        StringComparer.OrdinalIgnoreCase
                    )

                    .ToList();


            return words;
        }


        // =========================================================
        // NORMALIZE JOB KEYWORD
        // =========================================================

        private string NormalizeJobKeyword(
            string word)
        {
            var value =
                word
                    .Trim()
                    .ToLowerInvariant();


            return value switch
            {
                "ai" =>
                    "artificial-intelligence",

                "artificial" =>
                    "artificial-intelligence",

                "intelligence" =>
                    "artificial-intelligence",

                "ml" =>
                    "machine-learning",

                "machine" =>
                    "machine-learning",

                "learning" =>
                    "machine-learning",

                "dl" =>
                    "deep-learning",

                "deep" =>
                    "deep-learning",

                "data" =>
                    "data",

                "science" =>
                    "data",

                _ =>
                    value
            };
        }


        // =========================================================
        // SKILLS MATCH VACANCY
        // =========================================================

        private bool SkillsMatchVacancy(
            string? interviewerSkills,
            JobVacancy vacancy)
        {
            if (string.IsNullOrWhiteSpace(
                interviewerSkills))
            {
                return false;
            }


            var vacancyText =
                NormalizeMatchingText(
                    $"{vacancy.JobTitle} " +
                    $"{vacancy.Description} " +
                    $"{vacancy.Requirements} " +
                    $"{vacancy.PreferredRequirements}"
                );


            var skills =
                interviewerSkills

                    .Split(
                        new[]
                        {
                            ',',
                            ';',
                            '|'
                        },
                        StringSplitOptions.RemoveEmptyEntries
                    )

                    .Select(
                        x =>
                            NormalizeMatchingText(
                                x
                            )
                    )

                    .Where(
                        x =>
                            !string.IsNullOrWhiteSpace(x)
                    )

                    .ToList();


            return skills.Any(
                skill =>
                    skill.Length >= 2 &&
                    vacancyText.Contains(
                        skill
                    )
            );
        }


        // =========================================================
        // NORMALIZE MATCHING TEXT
        // =========================================================

        private string NormalizeMatchingText(
            string? value)
        {
            if (string.IsNullOrWhiteSpace(
                value))
            {
                return "";
            }


            var text =
                value
                    .Trim()
                    .ToLowerInvariant();


            text =
                text.Replace(
                    "artificial intelligence",
                    "ai"
                );


            text =
                text.Replace(
                    "machine learning",
                    "ml"
                );


            text =
                text.Replace(
                    "deep learning",
                    "dl"
                );


            return text;
        }


        // =========================================================
        // SAFE WORD CHECK
        // =========================================================

        private bool ContainsWord(
            string text,
            string word)
        {
            return Regex.IsMatch(
                text,
                $@"\b{Regex.Escape(word)}\b",
                RegexOptions.IgnoreCase
            );
        }
    }
}
    
